<script>

class Node {
    constructor(profit, weight, bound, level) {
        this.profit = profit
        this.weight = weight
        this.bound = bound
        this.level = level
    }
}

export default {

    data() {
        return {
            //DY Matrix
            matrix : [],
            showMatrix : false,
            //---------
            maxValue: 0,
            // For Tree 
            tree: [],
            // For Adding to the Lists
            wweight: '',
            vvalue: '',
            // Our Original Values
            value: [],
            weight: [],
            // LIMIT
            knapSackLimit: 50,
            // Value per Weight of items list
            VperW: [],
            // Answers
            answerDY: 0,
            answerDC: 0,
            answerGreedy: 0,
            answerBreatheFirst: 0,
            answerDepthFirst: 0,
            answerBestFirst: 0
        }
    },
    methods: {
        addItem() {
            this.value.push(parseInt(this.vvalue))
            this.weight.push(parseInt(this.wweight))
            this.VperW.push(parseInt(parseInt(this.vvalue) / parseInt(this.wweight)))
            this.vvalue = ''
            this.wweight = ''
        },
        max(a, b) {
            return (a > b) ? a : b;
        },
        bound(u, n, val, wt, W) {
            if (u.weight >= W) {
                return 0
            }
            let k
            let result = u.profit
            let j = u.level + 1
            let totWeight = u.weight
            while (j < n && totWeight + wt[j] <= W) {
                totWeight += wt[j]
                result += val[j]
                j += 1
            }
            k = j
            if (k < n) {
                result += (W - totWeight) * val[k] / wt[k]
            }
            return result
        },
        knapSackBreatheFirst(W, wt, val, n) {
            let Q = []
            let u = new Node(0, 0, 0, 0)
            let v = new Node(0, 0, 0, 0)

            Q.push(v)
            while (Q.length != 0) {
                v = Q.pop(0)
                if (v.level == n - 1) {
                    continue
                }
                u.level = v.level + 1
                u.weight = v.weight + wt[u.level]
                u.profit = v.profit + val[u.level]
                if (u.weight <= W && u.profit > this.maxValue) {
                    this.maxValue += u.profit
                }
                u.bound = this.bound(u, n, val, wt, W)
                if (u.bound > this.maxValue) {
                    Q.push(u)
                }
                u.weight = v.weight
                u.profit = v.profit
                u.bound = this.bound(u, n, val, wt, W)
                if (u.bound > this.maxValue) {
                    Q.push(u)
                }
            }
            this.answerBreatheFirst = this.maxValue
        },
        knapSackBestFirst(W, wt, val, n) {
            let maxValue
            let PQ = []
            let v = new Node(0, 0, 0, 0)
            let u = new Node(0, 0, 0, 0)
            maxValue = 0
            v.bound = this.bound(v, n, val, wt, W)
            PQ.push(v)
            while (PQ.length != 0) {
                PQ.pop()
                if (v.bound > maxValue) {
                    u.level = v.level + 1
                    u.weight = v.weight + wt[u.level - 1]
                    u.profit = v.profit + val[u.level - 1]

                    if (u.weight <= W && u.profit > maxValue) {
                        maxValue = u.profit
                    }
                    u.bound = this.bound(u, n, val, wt, W)
                    if (u.bound > maxValue) {
                        PQ.push(u)
                    }
                    u.weight = v.weight
                    u.profit = v.profit
                    u.bound = this.bound(u, n, val, wt, W)
                    if (u.bound > maxValue) {
                        PQ.push(u)
                    }
                }
            }
            this.answerBestFirst = maxValue
        },
        knapSackGreedy(W, wt, val, vps, n) {
            let answer = 0
            let maxWeight = W
            let j

            for (let i = 0; i < n; i++) {
                j = vps.indexOf(Math.max(...vps))
                vps = vps.filter((value) => { return value != vps[j] })

                if (wt[j] <= maxWeight) {
                    answer += val[j]
                    maxWeight -= wt[j]
                } else {
                    if (maxWeight > 0) {
                        wt[j] = maxWeight
                        answer += val[j]
                        maxWeight -= wt[j]
                    }
                    else {
                        if (maxWeight <= 0) {
                            break
                        }
                    }
                }
            }
            this.answerGreedy = answer
        },
        knapSackDC(W, wt, val, n) {

            if (n == 0 || W == 0)
                return 0;
            if (wt[n - 1] > W)
                return this.knapSackDC(W, wt, val, n - 1);
            else
                return this.max(val[n - 1] +
                    this.knapSackDC(W - wt[n - 1], wt, val, n - 1),
                    this.knapSackDC(W, wt, val, n - 1));
        },
        knapSackDY(W, wt, val, n) {
            this.showMatrix = true
            let i, w;
            let K = new Array(n + 1);

            for (i = 0; i <= n; i++) {
                K[i] = new Array(W + 1);
                for (w = 0; w <= W; w++) {
                    if (i == 0 || w == 0)
                        K[i][w] = 0;
                    else if (wt[i - 1] <= w)
                        K[i][w]
                            = this.max(val[i - 1]
                                + K[i - 1][w - wt[i - 1]],
                                K[i - 1][w]);
                    else
                        K[i][w] = K[i - 1][w];
                }
            }

            this.matrix = K
            this.answerDY = K[n][W];
        }
    },
}
</script>

<template>
    <div class="page container-fluid d-flex flex-column align-items-start justify-content-start">
        <div class="knapsack d-flex flex-column justify-content-around my-5">
            <div
                class="knapsack-input d-flex flex-column flex-md-row justify-content-around align-items-center mt-4 mx-5">
                <label for="value">Value:</label>
                <input type="text" class="textbox form-control" placeholder="Value ..." v-model="vvalue">
                <label for="weight">Weight:</label>
                <input type="text" class="textbox form-control" placeholder="Weight ..." v-model="wweight">
                <button class="btn btn-warning mt-3 mt-md-0" @click="addItem()">ADD</button>
            </div>
            <div
                class="knapsack-results d-flex flex-column flex-md-row justify-content-around text-center align-items-center mt-4 mx-5">
                <div class="result-layout m-2 d-flex flex-column justify-content-between p-2 col-10 col-md-2">
                    <h2>D&C</h2>
                    <h1>{{ answerDC }}</h1>
                </div>
                <div class="result-layout m-2 d-flex flex-column justify-content-between p-2 col-10 col-md-2">
                    <h2>Dynamic Programming</h2>
                    <h1>{{ answerDY }}</h1>
                </div>
                <div class="result-layout m-2 d-flex flex-column justify-content-between p-2 col-10 col-md-2">
                    <h2>Greedy</h2>
                    <h1>{{ answerGreedy }}</h1>
                </div>
                <div class="result-layout m-2 d-flex flex-column justify-content-between p-2 col-10 col-md-2">
                    <h2>B&B Breathe First</h2>
                    <h1>{{ answerBreatheFirst }}</h1>
                </div>
                <div class="result-layout m-2 d-flex flex-column justify-content-between p-2 col-10 col-md-2">
                    <h2>B&B Depth First</h2>
                    <h1>{{ answerDepthFirst }}</h1>
                </div>
                <div class="result-layout m-2 d-flex flex-column justify-content-between p-2 col-10 col-md-2">
                    <h2>B&B Best First</h2>
                    <h1>{{ answerBestFirst }}</h1>
                </div>
            </div>
            <div class="knapsack-calculate d-flex flex-row justify-content-center align-items-center">
                <button class="btn btn-danger my-4 mx-2"
                    @click="answerDC = knapSackDC(knapSackLimit, weight, value, value.length)">CALCULATE</button>
                <button class="btn btn-danger my-4 mx-2"
                    @click="knapSackDY(knapSackLimit, weight, value, value.length)">CALCULATE</button>
                <button class="btn btn-danger my-4 mx-2"
                    @click="knapSackGreedy(knapSackLimit, weight, value, VperW, value.length)">CALCULATE</button>
                <button class="btn btn-danger my-4 mx-2"
                    @click="answerBreatheFirst = knapSackDC(knapSackLimit, weight, value, value.length)">CALCULATE</button>
                <button class="btn btn-danger my-4 mx-2"
                    @click="answerDepthFirst = knapSackDC(knapSackLimit, weight, value, value.length)">CALCULATE</button>
                <button class="btn btn-danger my-4 mx-2">CALCULATE</button>
            </div>
        </div>
        <div class="dy-matrix d-flex flex-column justify-content-center my-3" v-if="showMatrix">
            <div v-for="n in value.length">
                <button class="btn" v-for="m in knapSackLimit" style="color : white;">{{ matrix[n][m] }}</button>
            </div>
        </div>
    </div>
</template>

<style scoped>
.page {
    background-color: darkslateblue;
    width: 100vw;
    height: 2500px;
}

.knapsack {
    background-color: aqua;
    width: 80vw;
    border-radius: 20px;
}

.textbox {
    width: 200px;
}

.result-layout {
    color: white;
    background-color: darkgreen;
    height: 300px;
    border-radius: 20px;
}
.dy-matrix{
    background-color: darkgreen;
    border-radius: 20px;
    max-width: 440px;
    cursor:pointer;
}
</style>
